function displayCode(){
  var x = document.getElementById("code");
  if (x.style.display === "none"){
    x.style.display= "block";
  }else{
    x.style.display = "none";
  }
}


function displayOutput(){
  var x = document.getElementById("output");
  if (x.style.display === "none"){
    x.style.display= "block";
  }else{
    x.style.display = "none";
  }
}
